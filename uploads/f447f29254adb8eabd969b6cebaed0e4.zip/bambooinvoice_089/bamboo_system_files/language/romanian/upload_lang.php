<?php

$lang['upload_userfile_not_set'] = "Imposibil de gasit un post variabil numit fisierul utilizatorului.";
$lang['upload_file_exceeds_limit'] = "Fisierul uploadat depaseste marimea maxima permisa in fisierul configuratiei PHP-ului tau";
$lang['upload_file_partial'] = "Fisierul a fost doar partial uploadat";
$lang['upload_no_file_selected'] = "Nu ai selectat un fisier pentru upload";
$lang['upload_invalid_filetype'] = "Tipul fisierului pe care incerci sa il uploadezi nu este permis";
$lang['upload_invalid_filesize'] = "Fisierul pe care incerci sa il uploadezi este mai mare decat marimea permisa";
$lang['upload_invalid_dimensions'] = "Imaginea pe care incerci sa o uploadezi depaseste inaltimea sau latimea maxima";
$lang['upload_destination_error'] = "O problema a fost intampinata in timpul mutarii fisierului uploadat la destinatia finala.";
$lang['upload_no_filepath'] = "Calea uploadului nu pare sa fie valida.";
$lang['upload_no_file_types'] = "Nu ai specificat nici un tip de fisier permis.";
$lang['upload_bad_filename'] = " Numele fisierului propus exista in server.";
$lang['upload_not_writable'] = "Folderul destinat uploadului nu pare sa fie scriptibil.";

?>