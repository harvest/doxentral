<?php

$lang['scaff_view_records']        = 'Bekijk Records';
$lang['scaff_create_record']    = 'Creer Nieuw Record';
$lang['scaff_add']                = 'Data Toevoegen';
$lang['scaff_view']                = 'Data Bekijken';
$lang['scaff_edit']                = 'Bewerk';
$lang['scaff_delete']            = 'Verwijder';
$lang['scaff_view_all']            = 'Bekijk alle';
$lang['scaff_yes']                = 'Ja';
$lang['scaff_no']                = 'Nee';
$lang['scaff_no_data']            = 'Er is nog geen data in deze tabel ingevoerd.';
$lang['scaff_del_confirm']        = 'Weet u zeker dat u de volgende row wilt verwijderen:';

?>