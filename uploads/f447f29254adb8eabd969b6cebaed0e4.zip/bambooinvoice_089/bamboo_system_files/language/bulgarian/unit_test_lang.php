<?php

$lang['ut_test_name']		= 'Тестово име';
$lang['ut_test_datatype']	= 'Тестови тип на данните';
$lang['ut_res_datatype']	= 'Очакван тип на данните';
$lang['ut_result']			= 'Резултат';
$lang['ut_undefined']		= 'Недефинирано тестово име';
$lang['ut_file']			= 'Файлово име';
$lang['ut_line']			= 'Номер на ред';
$lang['ut_passed']			= 'Осъществен';
$lang['ut_failed']			= 'Неосъществен';
$lang['ut_boolean']			= 'Boolean';
$lang['ut_integer']			= 'Integer';
$lang['ut_float']			= 'Float';
$lang['ut_double']			= 'Float'; // can be the same as float
$lang['ut_string']			= 'String';
$lang['ut_array']			= 'Array';
$lang['ut_object']			= 'Object';
$lang['ut_resource']		= 'Resource';
$lang['ut_null']			= 'Null'

?>