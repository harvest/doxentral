<?php

$lang['scaff_view_records']		= 'Виж записите';
$lang['scaff_create_record']	= 'Създай нов запис';
$lang['scaff_add']				= 'Добави данни';
$lang['scaff_view']				= 'Виж данните';
$lang['scaff_edit']				= 'Промени';
$lang['scaff_delete']			= 'Изтрий';
$lang['scaff_view_all']			= 'Виж всички';
$lang['scaff_yes']				= 'Да';
$lang['scaff_no']				= 'Не';
$lang['scaff_no_data']			= 'Няма данни за тази таблица все още.';
$lang['scaff_del_confirm']		= 'Сигурни ли сте, че изкате да изтриете този ред:';

?>