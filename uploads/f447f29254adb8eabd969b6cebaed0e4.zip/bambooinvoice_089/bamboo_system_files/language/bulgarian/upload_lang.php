<?php

$lang['upload_userfile_not_set'] = "Не може да бъде намерена променлива с името userfile.";
$lang['upload_file_exceeds_limit'] = "Каченият файл надхвърля размера, който е дефиниран в PHP конфигурационния файл.";
$lang['upload_file_partial'] = "Файлът беше частично качен.";
$lang['upload_no_file_selected'] = "Не сте избрали файл за качване.";
$lang['upload_invalid_filetype'] = "Файловият тип не е позволен.";
$lang['upload_invalid_filesize'] = "Файлът, който се опитвате да качите, надхвърля допустимата големина.";
$lang['upload_invalid_dimensions'] = "Файлът, който се опитвате да качите, надхвърля допустимите размери на ширина и височина.";
$lang['upload_destination_error'] = "Изникна проблем при опит да се изпрати файла към желаното място.";
$lang['upload_no_filepath'] = "Пътят на качените файлове не е валиден.";
$lang['upload_no_file_types'] = "Няма дефинирани допустими файлови типове.";
$lang['upload_bad_filename'] = "Името на файла вече съществува на сървъра.";
$lang['upload_not_writable'] = "Целевата папка не допуска записване на нови файлове.";

?>