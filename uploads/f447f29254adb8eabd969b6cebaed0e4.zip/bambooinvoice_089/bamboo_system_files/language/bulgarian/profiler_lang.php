<?php

$lang['profiler_benchmarks']	= 'ВРЕМЕНА ЗА ИЗПЪЛНЕНИЕ';
$lang['profiler_queries']		= 'ЗАЯВКИ КЪМ БАЗАТА ДАННИ';
$lang['profiler_post_data']		= 'POST ДАННИ';
$lang['profiler_files_data']	= 'FILES ДАННИ';
$lang['profiler_no_db']			= 'Драйверът за базата данни не е зареден';
$lang['profiler_no_queries']	= 'Не са изпълнени заявки към базата данни';
$lang['profiler_no_post']		= 'Няма POST данни';
$lang['profiler_no_files']		= 'Няма FILES данни';

?>