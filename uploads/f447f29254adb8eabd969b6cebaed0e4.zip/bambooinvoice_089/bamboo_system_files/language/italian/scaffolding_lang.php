<?php

$lang['scaff_view_records']		= 'Visualizza Record';
$lang['scaff_create_record']	= 'Crea nuovo Record';
$lang['scaff_add']				= 'Aggiungi Dati';
$lang['scaff_view']				= 'Visualizza Dati';
$lang['scaff_edit']				= 'Modifica';
$lang['scaff_delete']			= 'Elimina';
$lang['scaff_view_all']			= 'Visualizza Tutto';
$lang['scaff_yes']				= 'Si';
$lang['scaff_no']				= 'No';
$lang['scaff_no_data']			= 'Non esistono dati per questa tabella.';
$lang['scaff_del_confirm']		= 'Sei sicuro di voler elimnare questa riga:';


/* End of file scaffolding_lang.php */
/* Location: ./system/language/english/scaffolding_lang.php */