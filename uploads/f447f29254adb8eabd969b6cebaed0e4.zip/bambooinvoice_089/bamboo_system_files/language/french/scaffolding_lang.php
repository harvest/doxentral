<?php

$lang['scaff_view_records']		= 'Voir les enregistrements';
$lang['scaff_create_record']	= 'Cr&eacute;er un nouvel enregistrement';
$lang['scaff_add']				= 'Ajouter des donn&eacute;es';
$lang['scaff_view']				= 'Voir les donn&eacute;es';
$lang['scaff_edit']				= 'Modifier';
$lang['scaff_delete']			= 'Supprimer';
$lang['scaff_view_all']			= 'Voir tout';
$lang['scaff_yes']				= 'Oui';
$lang['scaff_no']				= 'Non';
$lang['scaff_no_data']			= 'Il n\'y a pas encore de donn&eacute;es pour cette table.';
$lang['scaff_del_confirm']		= 'Etes-vous s&ucirc;r(e) de vouloir supprimer cette entr&eacute;e:';

?>