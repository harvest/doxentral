<?php

$lang['scaff_view_records']		= 'Stze zeigen';
$lang['scaff_create_record']	= 'Neuer Satz';
$lang['scaff_add']				= 'Daten hinzufgen';
$lang['scaff_view']				= 'Daten zeigen';
$lang['scaff_edit']				= 'Bearbeiten';
$lang['scaff_delete']			= 'Lschen';
$lang['scaff_view_all']			= 'Alles zeigen';
$lang['scaff_yes']				= 'Ja';
$lang['scaff_no']				= 'Nein';
$lang['scaff_no_data']			= 'Fr diese Tabelle gibt es noch keine Daten.';
$lang['scaff_del_confirm']		= 'Wirklich die folgende Reihe zu lschen:';

?>