<?php

$lang['ut_test_name']		= 'Test Name';
$lang['ut_test_datatype']	= 'Test Datentyp ';
$lang['ut_res_datatype']	= 'Erwarteter Datentyp';
$lang['ut_result']			= 'Resultat';
$lang['ut_undefined']		= 'Unbestimmter Test Name';
$lang['ut_file']			= 'Datei Name';
$lang['ut_line']			= 'Linien Nummer';
$lang['ut_passed']			= 'Bestanden';
$lang['ut_failed']			= 'Durchgefallen';
$lang['ut_boolean']			= 'Boolean';
$lang['ut_integer']			= 'Integer';
$lang['ut_double']			= 'Float';
$lang['ut_float']			= 'Floag';
$lang['ut_string']			= 'String';
$lang['ut_array']			= 'Array';
$lang['ut_object']			= 'Objekt';
$lang['ut_resource']		= 'Resource';
$lang['ut_null']			= 'Null'

?>