<?php

$lang['db_invalid_connection_str'] = 'No foi possvel determinar as configuraes do banco de dados baseado na string de conexo enviada.';
$lang['db_unable_to_connect'] = 'No foi possvel conectar ao seu banco de dados usando as configuraes fornecidas.';
$lang['db_unable_to_select'] = 'No foi possvel selecionar o banco de dados especificado: %s';
$lang['db_unable_to_create'] = 'No foi possvel criar o banco de dados especificado: %s';
$lang['db_invalid_query'] = 'A instruo enviada no  vlida.';
$lang['db_must_set_table'] = 'Voc deve especificar a tabela do banco de dados a ser usada na sua instruo.';
$lang['db_must_use_set'] = 'Voc deve usar o mtodo "set" para atualizar um registro.';
$lang['db_must_use_where'] = 'Atualizaes no so permitidas se no contiverem um clusula "where".';
$lang['db_del_must_use_where'] = 'Remoes no so permitidas se no contiverem um clusula "where".';
$lang['db_field_param_missing'] = 'Para obter os campos o nome da tabela deve ser fornecido como parmetro.';
$lang['db_unsupported_function'] = 'Este recurso no est disponvel para o banco de dados que voc est usando.';

?>
