<?php

$lang['required'] 		= "O campo %s  obrigatrio.";
$lang['isset']			= "O campo %s deve conter um valor.";
$lang['valid_email']	= "O campo %s deve conter um endereo de email vlido.";
$lang['valid_url'] 		= "O campo %s deve conter uma URL vlida.";
$lang['min_length']		= "O campo %s deve ter pelo menos %s caracteres de comprimento.";
$lang['max_length']		= "O campo %s no pode exceder %s caracteres de comprimento.";
$lang['exact_length']	= "O campo %s deve conter exatamente %s caracteres de comprimento.";
$lang['alpha']			= "O campo %s deve conter apenas caracteres alfa-numricos.";
$lang['alpha_dash']		= "O campo %s deve conter apenas caracteres alfa-numricos, underscores, e hfen.";
$lang['numeric']		= "O campo %s deve conter um nmero.";
$lang['matches']		= "O campo %s deve ser igual ao campo %s.";


?>
