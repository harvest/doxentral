<html>
<head>
<title>BambooInvoice Installer</title>
<style type="text/css">
h1 {
	text-align: center;
}
div {
	margin: auto 50px;
	border: 1px solid #CCC;
	background: #F6F6F6; padding: 10px;
	font-family: Helvetica, Arial, Verdana, sans-serif;
}
.bamboo_invoice_bam {
	color: #5E88B6;
	font-weight: bold;
	text-transform: capitalize;
}
.bamboo_invoice_inv {
	font-weight: bold;
	font-variant: small-caps;
	color: #333;
}

label span {
	display: block;
	float: left;
	width: 170px;
	margin: 0;
}

label {
	line-height: 150%;
}

</style></head><body>

<h1><img src="<?php echo base_url();?>img/bambooinvoice_logo_isolated.png" width="296" height="60" alt="BambooInvoice" /></h1>

<div>