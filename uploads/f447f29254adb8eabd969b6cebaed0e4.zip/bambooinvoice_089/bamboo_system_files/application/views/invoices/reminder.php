<?php
$this->load->view('header');
?>
<h2><?php echo $page_title;?></h2>
<p>Not currently functional. This option won't be available if the invoice has not yet been emailed.</p>

<?php
$this->load->view('footer');
?>