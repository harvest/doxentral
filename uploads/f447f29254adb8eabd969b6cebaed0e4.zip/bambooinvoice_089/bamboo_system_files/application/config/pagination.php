<?php
$config['per_page'] = 20;
$config['first_link'] = '';
$config['last_link'] = '';
$config['next_link'] = 'next &gt;';
$config['prev_link'] = 'prev &lt;';
$config['full_tag_open'] = '<p id="pagination">';
$config['full_tag_close'] = '</p>';
$config['cur_tag_open'] = ' <strong>';
$config['cur_tag_close'] = '</strong>';
$config['num_links'] = 2;
?>